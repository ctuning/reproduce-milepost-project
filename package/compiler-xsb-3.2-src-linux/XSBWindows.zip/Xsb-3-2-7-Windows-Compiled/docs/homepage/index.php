<html>
<head>
<title> XSB </title>
<frameset ROWS="160,*" frameborder="NO" border="0" framespacing="0"> 
<frame SRC="XSBtop.php" NAME="top_window" SCROLLING="no" NORESIZE MARGINWIDTH="0"
      MARGINHEIGHT="0">
<frame SRC="home.php" NAME="middle_window" MARGINWIDTH="0"
      MARGINHEIGHT="0">
</frameset>
</head>
<body>
&nbsp;
</body>
</html>

