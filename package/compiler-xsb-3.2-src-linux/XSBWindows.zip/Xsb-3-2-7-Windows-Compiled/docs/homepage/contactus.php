<html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>Email Us</title>
</head>

<body>


		<FORM ACTION="sendemail.php" METHOD="POST">
                <INPUT TYPE="HIDDEN" NAME="post_message" VALUE="y">
                <TABLE>
                <TR>
                <tr>
                <td colspan=2>Please contact us at xsb-users@lists.sourceforge.net:</td>
                </tr>
                <TD><b>Subject:</b></TD><TD>
                <INPUT TYPE="TEXT" NAME="subject" VALUE="" SIZE="15" MAXLENGTH="40">
                </TD></TR>
                <TR><TD><B>Return Address:</b></TD><TD>
                <INPUT TYPE="TEXT" NAME="address" VALUE="" SIZE="15" MAXLENGTH="45">
                </TD></TR>
                <TR><TD><B>Message:</b></TD><TD>
                <TEXTAREA NAME="body" VALUE="" ROWS="5" COLS="50" WRAP="SOFT"></TEXTAREA>
                </TD></TR>
                <TR><TD COLSPAN="2" ALIGN="MIDDLE">
                <INPUT TYPE="SUBMIT" NAME="SUBMIT" VALUE="Send Email">
                </TD></TR></TABLE>
                </FORM>
<br>
<hr>
<br>
<h4> Our snail address is: </h4>
<address>
Computer Science Department<br>
Stony Brook University<br>
Stony Brook, NY 11794-4400<br>
+1-631-632-8470/8471 (Tel)<br>
+1-631-632-8334 (Fax)<br>
<br>
<A href="http://sourceforge.net">
<IMG src="http://sourceforge.net/sflogo.php?group_id=1176&amp;type=1" width="88" height="31" border="0" alt="SourceForge Logo"></A
>
<br>
</body>



</html>
