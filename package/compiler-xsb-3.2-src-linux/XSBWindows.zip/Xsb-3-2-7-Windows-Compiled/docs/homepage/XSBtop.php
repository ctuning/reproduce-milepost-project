<html>
<body>
<table border="0" cellpadding="0" cellspacing="0" height="130">
<tr>
	<td width="1" height="65"></td>
    <td width="130" align="center" height="100" rowspan="2"><img src="xsb-logo-anim2.gif" alt="xsb logo anim" width="120" height="80"> 
    </td>
    <td width="495" align="center" height="90" colspan="4" rowspan=2><img src="xsb-group.gif" alt="xsb-group" width="480" height="92"></td>
<td width=70 align="center" height=65 valign="middle"><A
href="http://www.stonybrook.edu/" target="middle_window">
<img src="Stonyxsb.gif" alt="Stony Brook" width="70" border="0"></A></td>
    <td width="90" height="65" align="center"><A HREF="http://www.kuleuven.ac.be/kuleuven/" target="middle_window"><img src="leuven.gif" alt="Katholieke Universiteit Leuven" BORDER="0" height="50" width="65"></a></td>
	<td width="1" height="25"></td>
</tr>
<tr>
<td width="1" height="35"></td>
<td rowspan=2 align="center"><A HREF="http://www.unl.pt/" target="middle_window"><img src="lisboa.jpg" alt="Universidade Nova de Lisboa" BORDER="0" height="51" width="65"></a></td>
<td rowspan=2 align="center"><A HREF="http://www.uu.se/" target="middle_window"><img src="uppsala.gif" alt="Uppsala Universitet" BORDER="0" height="50" width="64"></a></td>
	<td width="1" height="35"></td>
</tr>
<tr>
	<td width="3" height="30"></td>
<td valign="middle" align="center" height="30" width="130"><font color="#000080"><b>
<?php echo (`date "+%a %b %e %Y"`); ?>
</b></font></td>
<td height="30"><A HREF="home.php" target="middle_window"><img src="home.gif" alt="home" BORDER="0"></a></td>
<td height="30"><A HREF="research.php" target="middle_window"><img src="research.gif" alt="research" BORDER="0" ></a></td>
<td height="30"><A HREF="xsbsystem.php" target="middle_window"><img src="xsbsystem.gif" alt="XSB system" BORDER="0" ></a></td>
<td height="30"><A HREF="contactus.php" target="middle_window"><img src="contactus.gif" alt="contact us" BORDER="0" ></a></td>
	<td width="3" height="30"></td>
</tr>
</table>
<br>
</body>
</html>
