<head>
<meta http-equiv="refresh" content="0; url=http://flora.sourceforge.net/">
</head>
<body>
Click <a href="http://flora.sourceforge.net/">here</A> if your browser fails to forward you
to another page after a few seconds.
</body>
