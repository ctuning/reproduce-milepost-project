<html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>Email Us</title>
</head>

<body>

<p>
<P>&nbsp;<B>XSB development is hosted by 
<a href="http://sourceforge.com/">SourceForge</a></B>.

<P>SourceForge is a free hosting service for <A href="http://www.opensource.org">Open Source</A> 
developers which offers, among other things, a CVS repository, mailing lists,
bug tracking, message forums, task management software, web site hosting,
permanent file archival, full backups, and total web-based administration.
A more <A href="http://sourceforge.com/docs/site/services.php">complete description of services</A> is
available. 
<br>
<P>&nbsp;Sourceforge offers us the following services:
<UL>
<li><a href="http://sourceforge.net/bugs/?group_id=1176">Bug Tracking</li>
<li><a href="http://sourceforge.net/mail/?group_id=1176">Mailing Lists</li>
<li><a href="http://sourceforge.net/cvs/?group_id=1176">CVS Code Repository</li>
<li><a href="http://sourceforge.net/project/showfiles.php?group_id=1176">Source Code Download</li>
<li><a href="http://sourceforge.net/project/?group_id=1176">And More...</a></li>
</UL>
<br>
<A href="http://sourceforge.net">
<IMG src="http://sourceforge.net/sflogo.php?group_id=1176&amp;type=1" width="88" height="31" border="0" alt="SourceForge Logo"></A
>
<br>
</body>



</html>
