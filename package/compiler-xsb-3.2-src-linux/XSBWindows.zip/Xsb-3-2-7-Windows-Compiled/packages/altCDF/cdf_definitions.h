
#define TABLEDISA 1
#define USING_XJ 1
