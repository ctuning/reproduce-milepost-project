
#define TABLEDISA 0
#define USING_XJ 1
