#define XSB_SUCCESS 0
#define XSB_FAILURE 1
#define XSB_ERROR 2
#define XSB_OVERFLOW 3
#define XSB_IN_C			1
#define XSB_IN_Prolog		0

