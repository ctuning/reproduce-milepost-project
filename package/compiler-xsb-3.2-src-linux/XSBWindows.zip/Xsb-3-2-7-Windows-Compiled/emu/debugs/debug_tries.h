
#ifndef DEBUG_TRIE_DEFS

#define DEBUG_TRIE_DEFS


#undef DEBUG_TRIE_LOOKUP

#undef DEBUG_INTERN

#undef SHOW_HASHTABLE_ADDITIONS

#undef DEBUG_TRIE_STACK

#undef DEBUG_RECLAIM_DEL_RET

#undef PVPROF

#undef PVR_DEBUG_TC_INSTS


#endif

