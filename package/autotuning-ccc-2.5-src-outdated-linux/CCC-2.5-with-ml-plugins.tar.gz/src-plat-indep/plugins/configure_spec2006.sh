#/bin/sh
pushd /home/fursin/fggwork/spec2006
source shrc
popd
