<?php

# Copyright (C) 2004-2010 by Grigori Fursin
#
# http://fursin.net/research
# 
# UNIDAPT Group
# http://unidapt.org

$dir=getenv("CCC_PLUGINS");
if ($dir != "")
  $dir = $dir . "/";
$dir.="/include/";
include($dir . "ccc_script_functions.php");
include($dir . "ccc_script_functions_ml.php");

$prog_id1=getenv("PROG_ID1");
$prog_id2=getenv("PROG_ID2");
$plat_id=getenv("PLAT_ID");
$env_id=getenv("ENV_ID");
$cmplr_id=getenv("CMPLR_ID");
$ds_num1=getenv("DS_NUM1");
$ds_num2=getenv("DS_NUM2");
$ds_id=getenv("DS_ID");

$notes=getenv("NOTES");
$pg_use=(int)getenv("PG_USE");
$output_cor=1;
$output_cor1=getenv("OUTPUT_CORRECT");
if ($output_cor1=="0") $output_cor=0;

$run_time=getenv("RUN_TIME");
if ($run_time=="") $run_time="RUN_TIME";
$time_thr=(double)getenv("TIME_THRESHOLD");
if ($time_thr==0) $time_thr="0.3";
$file_tmp=getenv("CCC_FILE_TMP");
 if ($file_tmp=="") $file_tmp="tmp";

$sort=getenv("SORT");

// Output file with stats
$fname=getenv("CCC_STATS");
$fo=fopen($fname . ".txt", 'w') or die("Error: Can't open output file with stats for writing\n");

// Print various parameters
ccc_print($fo, "PROG_ID1=              " . $prog_id1 . "\n");
ccc_print($fo, "DS_NUM1=               " . $ds_num1 . "\n");
ccc_print($fo, "DS_ID1=                " . $ds_id1 . "\n");
ccc_print($fo, "PROG_ID2=              " . $prog_id2 . "\n");
ccc_print($fo, "DS_NUM2=               " . $ds_num2 . "\n");
ccc_print($fo, "DS_ID2=                " . $ds_id2 . "\n");
ccc_print($fo, "PLAT_ID=               " . $plat_id . "\n");
ccc_print($fo, "ENV_ID=                " . $env_id . "\n");
ccc_print($fo, "CMPLR_ID=              " . $cmplr_id . "\n");
ccc_print($fo, "\n");
ccc_print($fo, "NOTES=                 " . $notes . "\n");
ccc_print($fo, "PG_USE=                " . $pg_use . "\n");
ccc_print($fo, "OUTPUT_CORRECT=        " . $output_cor . "\n");
ccc_print($fo, "RUN_TIME=              " . $run_time . "\n");
ccc_print($fo, "TIME_THRESHOLD=        " . $time_thr . "\n");
ccc_print($fo, "\n");
ccc_print($fo, "SORT=                  " . $sort . "\n");
ccc_print($fo, "\n");
ccc_print($fo, "CCC_FILE_TMP=          " . $file_tmp . "\n");

// Database parameters
$c_hostname=getenv("CCC_C_URL");
$c_database=getenv("CCC_C_DB");
$c_user    =getenv("CCC_C_USER");
$c_password=getenv("CCC_C_PASS");
$c_ssl     =getenv("CCC_C_SSL");
$ic_ssl=0;
if ($c_ssl != "") $ic_ssl=MYSQL_CLIENT_SSL;

$ct_hostname=getenv("CCC_CT_URL");
$ct_database=getenv("CCC_CT_DB");
$ct_user    =getenv("CCC_CT_USER");
$ct_password=getenv("CCC_CT_PASS");
$ct_ssl     =getenv("CCC_CT_SSL");
$ict_ssl=0;
if ($ct_ssl != "") $ict_ssl=MYSQL_CLIENT_SSL;

$hostname=getenv("CCC_URL");
$database=getenv("CCC_DB");
$user    =getenv("CCC_USER");
$password=getenv("CCC_PASS");
$ssl     =getenv("CCC_SSL");
$i_ssl=0;
if ($ssl != "") $i_ssl=MYSQL_CLIENT_SSL;

$db_ver=getenv("CCC_DB_VER");

// Connect to the common database
echo "\n";
echo "Connecting to the common database ...\n";
$c_link=mysql_connect($c_hostname, $c_user, $c_password, true, $ic_ssl) or die( "Error: Unable to connect to the database\n");
ccc_mysql_select_db($c_database, $c_link, $db_ver);

// Connect to the database with experiments
echo "Connecting to the database with experiments $database ...\n";
$link=mysql_connect($hostname, $user, $password, true, $i_ssl) or die( "Error: Unable to connect to the database\n");
ccc_mysql_select_db($database, $link, $db_ver);

//Checking dataset id
ccc_print($fo, "\n");
if ($ds_num1!="0")
{
 ccc_print($fo, "Searching DS_ID associated with DS_NUM (" . $ds_num1 .")...\n");
 $ds_id1=get_dataset_id($prog_id1, $ds_num1, $c_link);
}

ccc_print($fo, "\n");
if ($ds_num2!="0")
{
 ccc_print($fo, "Searching DS_ID associated with DS_NUM (" . $ds_num2 .")...\n");
 $ds_id2=get_dataset_id($prog_id2, $ds_num2, $c_link);
}

ccc_print($fo, "DS_ID1=                 " . $ds_id1 . "\n");
ccc_print($fo, "DS_ID2=                 " . $ds_id2 . "\n");

ccc_print($fo, "\n");
ccc_print($fo, "*** PROGRAM1:\n");
$feat1=get_features_by_prog_id($prog_id1);
ccc_print($fo, "Features = " . $feat1 . "\n");
$vfeat1=parse_sfv($feat1);
$nvfeat1=sfv_normalize($vfeat1,24);

ccc_print($fo, "*** PROGRAM2:\n");
$feat2=get_features_by_prog_id($prog_id2);
ccc_print($fo, "Features = " . $feat2 . "\n");
$vfeat2=parse_sfv($feat2);
$nvfeat2=sfv_normalize($vfeat2,24);

$qavf=sprintf("%2.3f", compare_sfv_ed($nvfeat1,$nvfeat2));

ccc_print($fo, $qavf . "\n");

fwrite($fo, "Difference (%) = " . $qavf . "\n");
fclose($fo);

$fo=fopen($fname . ".short.txt", 'w') or die("Error: Can't open output file with stats for writing\n");
fwrite($fo, $qavf . "\n");
fclose($fo);

exit;

function get_features_by_prog_id($prog_id) 
{
  switch ($prog_id) 
  {
    case "957266962420293" : return "ft1=138, ft2=51, ft3=78, ft4=0, ft5=97, ft6=25, ft7=10, ft8=42, ft9=52, ft10=6, ft11=19, ft12=0, ft13=111, ft14=21, ft15=0, ft16=213, ft17=62, ft18=0, ft24=2112, ft25=44.35, ft19=2, ft39=0, ft20=78, ft21=0, ft33=0, ft21=2029, ft35=307, ft22=588, ft23=11, ft34=392, ft36=287, ft37=0, ft38=0, ft40=42, ft41=359, ft42=0, ft43=1, ft44=1, ft45=0, ft46=101, ft48=149, ft47=537, ft49=0, ft51=0, ft50=4828, ft52=435, ft53=0, ft54=64, ft55=0, ft26=2.36, ft27=8.63, ft28=29, ft29=9, ft30=94, ft31=0, ft32=38";
    case "1487849553352134" : return "ft1=109, ft2=23, ft3=82, ft4=0, ft5=94, ft6=11, ft7=2, ft8=19, ft9=73, ft10=2, ft11=9, ft12=0, ft13=99, ft14=8, ft15=0, ft16=189, ft17=71, ft18=0, ft24=1409, ft25=13.1682, ft19=7, ft39=0, ft20=82, ft21=0, ft33=0, ft21=1319, ft35=143, ft22=301, ft23=24, ft34=183, ft36=137, ft37=0, ft38=0, ft40=2, ft41=181, ft42=0, ft43=4, ft44=3, ft45=1, ft46=11, ft48=43, ft47=199, ft49=0, ft51=1, ft50=3136, ft52=392, ft53=1, ft54=79, ft55=1, ft26=0.233645, ft27=6.44, ft28=16, ft29=0, ft30=91, ft31=0, ft32=16";
    case "5870527876570825" : return "ft1=42, ft2=22, ft3=15, ft4=0, ft5=27, ft6=13, ft7=0, ft8=20, ft9=6, ft10=2, ft11=9, ft12=0, ft13=37, ft14=3, ft15=0, ft16=54, ft17=4, ft18=0, ft24=275, ft25=6.88, ft19=13, ft39=0, ft20=15, ft21=0, ft33=0, ft21=246, ft35=32, ft22=73, ft23=5, ft34=71, ft36=23, ft37=0, ft38=0, ft40=0, ft41=33, ft42=1, ft43=8, ft44=2, ft45=6, ft46=11, ft48=28, ft47=48, ft49=0, ft51=0, ft50=668, ft52=98, ft53=0, ft54=15, ft55=0, ft26=1.02, ft27=1.80, ft28=13, ft29=2, ft30=25, ft31=0, ft32=15";
    case "1376981616525899" : return "ft1=20, ft2=8, ft3=6, ft4=0, ft5=10, ft6=6, ft7=0, ft8=6, ft9=4, ft10=2, ft11=2, ft12=0, ft13=12, ft14=4, ft15=0, ft16=24, ft17=4, ft18=0, ft24=836, ft25=179.50, ft19=2, ft39=0, ft20=6, ft21=0, ft33=0, ft21=826, ft35=55, ft22=496, ft23=0, ft34=34, ft36=57, ft37=1, ft38=0, ft40=2, ft41=371, ft42=0, ft43=2, ft44=0, ft45=0, ft46=16, ft48=27, ft47=394, ft49=0, ft51=0, ft50=2008, ft52=108, ft53=0, ft54=28, ft55=0, ft26=2.75, ft27=3.70, ft28=4, ft29=4, ft30=8, ft31=0, ft32=8";
    case "73095714612798533" : return "ft1=20, ft2=8, ft3=6, ft4=0, ft5=10, ft6=6, ft7=0, ft8=6, ft9=4, ft10=2, ft11=2, ft12=0, ft13=12, ft14=4, ft15=0, ft16=24, ft17=4, ft18=0, ft24=836, ft25=179.50, ft19=2, ft39=0, ft20=6, ft21=0, ft33=0, ft21=826, ft35=55, ft22=496, ft23=0, ft34=34, ft36=57, ft37=1, ft38=0, ft40=2, ft41=371, ft42=0, ft43=2, ft44=0, ft45=0, ft46=16, ft48=27, ft47=394, ft49=0, ft51=0, ft50=2008, ft52=108, ft53=0, ft54=28, ft55=0, ft26=2.75, ft27=3.70, ft28=4, ft29=4, ft30=8, ft31=0, ft32=8";
    case "903400302629443" : return "ft1=84, ft2=34, ft3=41, ft4=1, ft5=47, ft6=29, ft7=4, ft8=24, ft9=22, ft10=9, ft11=18, ft12=0, ft13=78, ft14=2, ft15=0, ft16=126, ft17=43, ft18=0, ft24=354, ft25=11.07, ft19=7, ft39=0, ft20=41, ft21=0, ft33=1, ft21=297, ft35=45, ft22=56, ft23=0, ft34=74, ft36=28, ft37=0, ft38=0, ft40=1, ft41=61, ft42=0, ft43=7, ft44=0, ft45=0, ft46=32, ft48=23, ft47=98, ft49=0, ft51=28, ft50=915, ft52=106, ft53=1, ft54=24, ft55=0, ft26=3.09, ft27=4.76, ft28=16, ft29=12, ft30=52, ft31=0, ft32=28";
    case "2691450257728454" : return "ft1=102, ft2=45, ft3=44, ft4=2, ft5=54, ft6=37, ft7=5, ft8=28, ft9=23, ft10=15, ft11=20, ft12=0, ft13=86, ft14=10, ft15=0, ft16=153, ft17=51, ft18=0, ft24=632, ft25=28.45, ft19=7, ft39=0, ft20=44, ft21=0, ft33=2, ft21=562, ft35=107, ft22=135, ft23=0, ft34=130, ft36=73, ft37=0, ft38=0, ft40=1, ft41=154, ft42=0, ft43=7, ft44=0, ft45=0, ft46=34, ft48=39, ft47=201, ft49=0, ft51=28, ft50=1542, ft52=133, ft53=1, ft54=29, ft55=0, ft26=5.09, ft27=6.76, ft28=24, ft29=14, ft30=58, ft31=0, ft32=38";
    case "694947654201031" : return "ft1=462, ft2=232, ft3=215, ft4=0, ft5=285, ft6=143, ft7=26, ft8=162, ft9=120, ft10=57, ft11=83, ft12=0, ft13=454, ft14=0, ft15=0, ft16=670, ft17=149, ft18=0, ft24=1384, ft25=16.45, ft19=23, ft39=0, ft20=215, ft21=0, ft33=0, ft21=1142, ft35=95, ft22=323, ft23=0, ft34=335, ft36=68, ft37=0, ft38=0, ft40=3, ft41=247, ft42=0, ft43=23, ft44=0, ft45=8, ft46=152, ft48=70, ft47=450, ft49=0, ft51=88, ft50=3488, ft52=470, ft53=9, ft54=60, ft55=0, ft26=4.29, ft27=8.90, ft28=143, ft29=20, ft30=291, ft31=0, ft32=163";
    case "64205605711423556" : return "ft1=247, ft2=124, ft3=99, ft4=2, ft5=148, ft6=71, ft7=14, ft8=110, ft9=33, ft10=8, ft11=62, ft12=1, ft13=228, ft14=5, ft15=0, ft16=344, ft17=65, ft18=0, ft24=704, ft25=20.87, ft19=17, ft39=0, ft20=99, ft21=0, ft33=2, ft21=565, ft35=39, ft22=178, ft23=0, ft34=76, ft36=23, ft37=0, ft38=0, ft40=14, ft41=142, ft42=0, ft43=11, ft44=5, ft45=6, ft46=68, ft48=62, ft47=236, ft49=0, ft51=383, ft50=1566, ft52=229, ft53=22, ft54=38, ft55=6, ft26=8.22, ft27=14.93, ft28=71, ft29=15, ft30=147, ft31=0, ft32=86";
    case "684553313031629" : return "ft1=40, ft2=18, ft3=11, ft4=2, ft5=19, ft6=14, ft7=1, ft8=12, ft9=5, ft10=6, ft11=6, ft12=0, ft13=26, ft14=6, ft15=2, ft16=54, ft17=14, ft18=0, ft24=2495, ft25=351.51, ft19=14, ft39=0, ft20=11, ft21=0, ft33=2, ft21=2457, ft35=131, ft22=804, ft23=0, ft34=910, ft36=126, ft37=2, ft38=0, ft40=1, ft41=475, ft42=0, ft43=14, ft44=0, ft45=12, ft46=135, ft48=124, ft47=967, ft49=0, ft51=896, ft50=5509, ft52=652, ft53=4, ft54=111, ft55=0, ft26=5.39, ft27=5.95, ft28=10, ft29=8, ft30=16, ft31=0, ft32=18";
    case "3416195471180235" : return "ft1=39, ft2=17, ft3=12, ft4=1, ft5=22, ft6=10, ft7=1, ft8=12, ft9=8, ft10=5, ft11=4, ft12=0, ft13=28, ft14=4, ft15=1, ft16=51, ft17=9, ft18=0, ft24=1318, ft25=182.46, ft19=11, ft39=0, ft20=12, ft21=0, ft33=1, ft21=1287, ft35=69, ft22=420, ft23=0, ft34=466, ft36=64, ft37=1, ft38=0, ft40=4, ft41=251, ft42=0, ft43=11, ft44=0, ft45=11, ft46=77, ft48=70, ft47=519, ft49=0, ft51=476, ft50=2891, ft52=380, ft53=6, ft54=70, ft55=0, ft26=4.06, ft27=6.33, ft28=6, ft29=5, ft30=22, ft31=0, ft32=11";
    case "90694025016038223" : return "ft1=31, ft2=15, ft3=13, ft4=0, ft5=17, ft6=11, ft7=1, ft8=14, ft9=3, ft10=1, ft11=9, ft12=0, ft13=29, ft14=0, ft15=0, ft16=43, ft17=10, ft18=0, ft24=56, ft25=1.93103, ft19=0, ft39=0, ft20=13, ft21=0, ft33=0, ft21=42, ft35=2, ft22=21, ft23=0, ft34=9, ft36=1, ft37=0, ft38=0, ft40=0, ft41=12, ft42=0, ft43=0, ft44=0, ft45=0, ft46=12, ft48=5, ft47=31, ft49=0, ft51=3, ft50=150, ft52=27, ft53=2, ft54=5, ft55=0, ft26=0.931034, ft27=2.03704, ft28=11, ft29=1, ft30=17, ft31=0, ft32=12";
    case "6102568384825923" : return "ft1=25, ft2=12, ft3=10, ft4=0, ft5=14, ft6=8, ft7=1, ft8=11, ft9=2, ft10=0, ft11=8, ft12=0, ft13=23, ft14=0, ft15=0, ft16=34, ft17=7, ft18=0, ft24=47, ft25=2.04348, ft19=0, ft39=0, ft20=10, ft21=0, ft33=0, ft21=36, ft35=2, ft22=19, ft23=0, ft34=6, ft36=1, ft37=0, ft38=0, ft40=0, ft41=15, ft42=0, ft43=0, ft44=0, ft45=0, ft46=11, ft48=3, ft47=31, ft49=0, ft51=7, ft50=119, ft52=26, ft53=2, ft54=5, ft55=0, ft26=0.913043, ft27=2.04762, ft28=8, ft29=1, ft30=14, ft31=0, ft32=9";
    case "4324827713289550" : return "ft1=111, ft2=27, ft3=23, ft4=0, ft5=51, ft6=18, ft7=2, ft8=24, ft9=15, ft10=3, ft11=8, ft12=0, ft13=67, ft14=4, ft15=0, ft16=113, ft17=15, ft18=0, ft24=352, ft25=192.34, ft19=21, ft39=1, ft20=23, ft21=0, ft33=0, ft21=287, ft35=11, ft22=111, ft23=0, ft34=79, ft36=11, ft37=0, ft38=0, ft40=7, ft41=84, ft42=0, ft43=16, ft44=5, ft45=14, ft46=49, ft48=36, ft47=73, ft49=51, ft51=32, ft50=717, ft52=253, ft53=9, ft54=42, ft55=2, ft26=7.15, ft27=22.23, ft28=19, ft29=2, ft30=50, ft31=5, ft32=16";
    case "7622823404188227" : return "ft1=5142, ft2=2167, ft3=1954, ft4=37, ft5=2970, ft6=1251, ft7=267, ft8=1698, ft9=1078, ft10=352, ft11=795, ft12=5, ft13=4298, ft14=190, ft15=0, ft16=6890, ft17=1428, ft18=0, ft24=20645, ft25=1919.13, ft19=683, ft39=645, ft20=1954, ft21=0, ft33=37, ft21=16823, ft35=1350, ft22=3467, ft23=153, ft34=2079, ft36=937, ft37=314, ft38=0, ft40=958, ft41=3058, ft42=72, ft43=1258, ft44=205, ft45=357, ft46=2572, ft48=1571, ft47=7314, ft49=0, ft51=319, ft50=43592, ft52=9870, ft53=57, ft54=3748, ft55=18, ft26=165.02, ft27=556.61, ft28=1268, ft29=197, ft30=3023, ft31=36, ft32=1429";
    case "7097459005644868" : return "ft1=4926, ft2=2077, ft3=1881, ft4=32, ft5=2847, ft6=1205, ft7=252, ft8=1624, ft9=1044, ft10=344, ft11=758, ft12=4, ft13=4127, ft14=177, ft15=0, ft16=6603, ft17=1370, ft18=0, ft24=19721, ft25=1859.45, ft19=696, ft39=597, ft20=1881, ft21=0, ft33=32, ft21=16048, ft35=1285, ft22=3333, ft23=153, ft34=1950, ft36=909, ft37=305, ft38=0, ft40=924, ft41=2932, ft42=67, ft43=1235, ft44=198, ft45=358, ft46=2493, ft48=1455, ft47=6976, ft49=0, ft51=316, ft50=41453, ft52=9479, ft53=53, ft54=3597, ft55=15, ft26=154.88, ft27=527.69, ft28=1214, ft29=188, ft30=2902, ft31=42, ft32=1360";
    case "2883352428829249" : return "ft1=9021, ft2=3912, ft3=3462, ft4=15, ft5=5385, ft6=2376, ft7=330, ft8=3279, ft9=1587, ft10=504, ft11=1731, ft12=0, ft13=7776, ft14=315, ft15=0, ft16=11823, ft17=2061, ft18=0, ft24=35427, ft25=2579.63, ft19=2118, ft39=0, ft20=3459, ft21=0, ft33=18, ft21=29259, ft35=2334, ft22=5214, ft23=3864, ft34=3519, ft36=1716, ft37=150, ft38=0, ft40=993, ft41=5271, ft42=144, ft43=1527, ft44=513, ft45=651, ft46=4764, ft48=2421, ft47=12687, ft49=0, ft51=5502, ft50=77739, ft52=17070, ft53=900, ft54=3618, ft55=120, ft26=245.64, ft27=724.41, ft28=2601, ft29=462, ft30=5028, ft31=54, ft32=3009";
    case "8640497457014986" : return "ft1=1710, ft2=554, ft3=647, ft4=33, ft5=985, ft6=308, ft7=113, ft8=429, ft9=463, ft10=98, ft11=148, ft12=1, ft13=1381, ft14=25, ft15=0, ft16=2346, ft17=655, ft18=0, ft24=4715, ft25=514.21, ft19=473, ft39=1, ft20=644, ft21=0, ft33=36, ft21=3203, ft35=359, ft22=846, ft23=0, ft34=499, ft36=319, ft37=21, ft38=0, ft40=89, ft41=875, ft42=7, ft43=408, ft44=100, ft45=244, ft46=812, ft48=308, ft47=1994, ft49=0, ft51=64, ft50=9546, ft52=2149, ft53=25, ft54=681, ft55=0, ft26=66.27, ft27=339.53, ft28=349, ft29=32, ft30=1024, ft31=50, ft32=331";
    case "7233828816653634" : return "ft1=3007, ft2=1304, ft3=1154, ft4=5, ft5=1795, ft6=792, ft7=110, ft8=1093, ft9=529, ft10=168, ft11=577, ft12=0, ft13=2592, ft14=105, ft15=0, ft16=3941, ft17=687, ft18=0, ft24=11809, ft25=859.88, ft19=706, ft39=0, ft20=1153, ft21=0, ft33=6, ft21=9753, ft35=778, ft22=1738, ft23=1288, ft34=1173, ft36=572, ft37=50, ft38=0, ft40=331, ft41=1757, ft42=48, ft43=509, ft44=171, ft45=217, ft46=1588, ft48=807, ft47=4229, ft49=0, ft51=1834, ft50=25913, ft52=5690, ft53=300, ft54=1206, ft55=40, ft26=81.88, ft27=241.47, ft28=867, ft29=154, ft30=1676, ft31=18, ft32=1003";
    case "7871909753945293" : return "ft1=1721, ft2=647, ft3=849, ft4=3, ft5=1086, ft6=367, ft7=130, ft8=500, ft9=546, ft10=102, ft11=244, ft12=0, ft13=1573, ft14=10, ft15=0, ft16=2517, ft17=717, ft18=0, ft24=5051, ft25=237.52, ft19=720, ft39=0, ft20=849, ft21=0, ft33=3, ft21=3375, ft35=281, ft22=466, ft23=1, ft34=707, ft36=266, ft37=4, ft38=0, ft40=113, ft41=538, ft42=39, ft43=620, ft44=151, ft45=431, ft46=1168, ft48=354, ft47=1867, ft49=0, ft51=1540, ft50=9195, ft52=2036, ft53=235, ft54=752, ft55=75, ft26=38.18, ft27=136.94, ft28=365, ft29=69, ft30=1149, ft31=3, ft32=431";
    case "5229001756118476" : return "ft1=2820, ft2=1116, ft3=1185, ft4=18, ft5=1659, ft6=651, ft7=186, ft8=831, ft9=738, ft10=219, ft11=369, ft12=0, ft13=2442, ft14=54, ft15=0, ft16=3912, ft17=975, ft18=0, ft24=9207, ft25=806.21, ft19=1272, ft39=6, ft20=1185, ft21=0, ft33=18, ft21=6462, ft35=459, ft22=987, ft23=366, ft34=1242, ft36=453, ft37=18, ft38=0, ft40=216, ft41=951, ft42=90, ft43=1053, ft44=120, ft45=618, ft46=2079, ft48=558, ft47=3177, ft49=0, ft51=2571, ft50=18147, ft52=4425, ft53=507, ft54=1089, ft55=108, ft26=102.63, ft27=314.87, ft28=594, ft29=153, ft30=1749, ft31=42, ft32=705";
    case "3509470022313024" : return "ft1=6070, ft2=2378, ft3=2725, ft4=16, ft5=3718, ft6=1319, ft7=409, ft8=1949, ft9=1655, ft10=328, ft11=883, ft12=1, ft13=5378, ft14=67, ft15=1, ft16=8570, ft17=2163, ft18=0, ft24=18324, ft25=1871.78, ft19=3932, ft39=0, ft20=2725, ft21=0, ft33=16, ft21=11195, ft35=663, ft22=2609, ft23=0, ft34=2637, ft36=534, ft37=110, ft38=0, ft40=413, ft41=2139, ft42=131, ft43=3499, ft44=1034, ft45=2252, ft46=4199, ft48=1228, ft47=6489, ft49=0, ft51=5378, ft50=35289, ft52=8471, ft53=883, ft54=2913, ft55=202, ft26=200.02, ft27=602.46, ft28=1279, ft29=328, ft30=3839, ft31=40, ft32=1567";
    case "17067991711258702" : return "ft1=15426, ft2=6501, ft3=5862, ft4=111, ft5=8910, ft6=3753, ft7=801, ft8=5094, ft9=3234, ft10=1056, ft11=2385, ft12=15, ft13=12894, ft14=570, ft15=0, ft16=20670, ft17=4284, ft18=0, ft24=61935, ft25=5757.40, ft19=2049, ft39=1935, ft20=5862, ft21=0, ft33=111, ft21=50469, ft35=4050, ft22=10401, ft23=459, ft34=6237, ft36=2811, ft37=942, ft38=0, ft40=2874, ft41=9174, ft42=216, ft43=3774, ft44=615, ft45=1071, ft46=7716, ft48=4713, ft47=21942, ft49=0, ft51=957, ft50=130776, ft52=29610, ft53=171, ft54=11244, ft55=54, ft26=495.07, ft27=1669.84, ft28=3804, ft29=591, ft30=9069, ft31=108, ft32=4287";
    case "15543429452673" : return "ft1=74, ft2=28, ft3=18, ft4=0, ft5=40, ft6=15, ft7=1, ft8=26, ft9=7, ft10=2, ft11=11, ft12=0, ft13=54, ft14=2, ft15=0, ft16=82, ft17=5, ft18=0, ft24=241, ft25=47.09, ft19=29, ft39=0, ft20=18, ft21=0, ft33=0, ft21=185, ft35=9, ft22=70, ft23=0, ft34=24, ft36=6, ft37=6, ft38=0, ft40=8, ft41=41, ft42=1, ft43=28, ft44=7, ft45=8, ft46=24, ft48=21, ft47=118, ft49=0, ft51=13, ft50=565, ft52=134, ft53=3, ft54=37, ft55=3, ft26=6.56, ft27=13.43, ft28=10, ft29=10, ft30=36, ft31=1, ft32=19";
    case "571025541354629" : return "ft1=36, ft2=13, ft3=8, ft4=0, ft5=18, ft6=8, ft7=0, ft8=11, ft9=4, ft10=2, ft11=4, ft12=0, ft13=26, ft14=0, ft15=0, ft16=39, ft17=3, ft18=0, ft24=79, ft25=18.64, ft19=13, ft39=0, ft20=8, ft21=0, ft33=0, ft21=53, ft35=2, ft22=18, ft23=0, ft34=15, ft36=4, ft37=0, ft38=0, ft40=2, ft41=13, ft42=0, ft43=13, ft44=2, ft45=8, ft46=12, ft48=5, ft47=29, ft49=0, ft51=10, ft50=177, ft52=64, ft53=4, ft54=18, ft55=1, ft26=4.36, ft27=7.86, ft28=6, ft29=3, ft30=17, ft31=0, ft32=9";
    case "2774585832306881" : return "ft1=1262, ft2=519, ft3=480, ft4=5, ft5=766, ft6=312, ft7=42, ft8=381, ft9=305, ft10=131, ft11=158, ft12=1, ft13=1091, ft14=24, ft15=5, ft16=1652, ft17=297, ft18=0, ft24=6995, ft25=2108.64, ft19=418, ft39=5, ft20=479, ft21=0, ft33=6, ft21=5982, ft35=537, ft22=1838, ft23=0, ft34=1756, ft36=519, ft37=9, ft38=0, ft40=37, ft41=1714, ft42=27, ft43=277, ft44=38, ft45=262, ft46=555, ft48=514, ft47=2664, ft49=0, ft51=585, ft50=14337, ft52=3424, ft53=96, ft54=575, ft55=50, ft26=30.43, ft27=146.31, ft28=329, ft29=38, ft30=753, ft31=21, ft32=346";
    case "50069414914239816" : return "ft1=75, ft2=27, ft3=31, ft4=0, ft5=40, ft6=22, ft7=3, ft8=22, ft9=16, ft10=4, ft11=13, ft12=0, ft13=64, ft14=1, ft15=0, ft16=99, ft17=27, ft18=0, ft24=176, ft25=12.81, ft19=27, ft39=3, ft20=31, ft21=0, ft33=0, ft21=109, ft35=16, ft22=20, ft23=3, ft34=30, ft36=3, ft37=0, ft38=0, ft40=0, ft41=16, ft42=1, ft43=24, ft44=3, ft45=16, ft46=20, ft48=19, ft47=49, ft49=0, ft51=5, ft50=474, ft52=110, ft53=2, ft54=41, ft55=2, ft26=4.95, ft27=10.20, ft28=15, ft29=9, ft30=41, ft31=2, ft32=22";
    case "34236622011175745" : return "ft1=60, ft2=21, ft3=18, ft4=0, ft5=34, ft6=13, ft7=1, ft8=19, ft9=10, ft10=1, ft11=8, ft12=0, ft13=44, ft14=4, ft15=0, ft16=69, ft17=8, ft18=0, ft24=259, ft25=28.67, ft19=35, ft39=0, ft20=18, ft21=0, ft33=0, ft21=200, ft35=11, ft22=37, ft23=0, ft34=34, ft36=2, ft37=0, ft38=0, ft40=7, ft41=28, ft42=0, ft43=24, ft44=5, ft45=18, ft46=18, ft48=20, ft47=61, ft49=0, ft51=201, ft50=427, ft52=115, ft53=20, ft54=52, ft55=9, ft26=2.89, ft27=7.85, ft28=8, ft29=5, ft30=35, ft31=3, ft32=10";
    case "806788555215306" : return "ft1=140, ft2=56, ft3=57, ft4=0, ft5=91, ft6=34, ft7=3, ft8=48, ft9=33, ft10=8, ft11=24, ft12=0, ft13=128, ft14=0, ft15=0, ft16=182, ft17=29, ft18=0, ft24=445, ft25=19.90, ft19=62, ft39=0, ft20=57, ft21=0, ft33=0, ft21=320, ft35=13, ft22=57, ft23=0, ft34=52, ft36=3, ft37=0, ft38=0, ft40=3, ft41=46, ft42=0, ft43=45, ft44=27, ft45=11, ft46=70, ft48=41, ft47=122, ft49=0, ft51=4, ft50=909, ft52=223, ft53=2, ft54=84, ft55=2, ft26=3.12, ft27=12.27, ft28=36, ft29=4, ft30=88, ft31=0, ft32=40";
    case "84586442211487560" : return "ft1=170, ft2=63, ft3=69, ft4=0, ft5=95, ft6=52, ft7=3, ft8=47, ft9=34, ft10=16, ft11=35, ft12=0, ft13=145, ft14=5, ft15=0, ft16=221, ft17=53, ft18=0, ft24=550, ft25=34.56, ft19=67, ft39=0, ft20=69, ft21=0, ft33=0, ft21=404, ft35=39, ft22=83, ft23=0, ft34=99, ft36=37, ft37=0, ft38=0, ft40=8, ft41=61, ft42=1, ft43=51, ft44=21, ft45=36, ft46=91, ft48=36, ft47=158, ft49=0, ft51=115, ft50=1089, ft52=291, ft53=35, ft54=102, ft55=10, ft26=5.19, ft27=18.69, ft28=57, ft29=2, ft30=91, ft31=0, ft32=59";
    case "4938583754917323" : return "ft1=2977, ft2=1319, ft3=1349, ft4=14, ft5=1927, ft6=746, ft7=134, ft8=1080, ft9=773, ft10=205, ft11=514, ft12=3, ft13=2556, ft14=250, ft15=1, ft16=4296, ft17=973, ft18=0, ft24=13988, ft25=300.34, ft19=568, ft39=20, ft20=1349, ft21=0, ft33=14, ft21=11830, ft35=864, ft22=3103, ft23=12, ft34=1455, ft36=734, ft37=40, ft38=0, ft40=382, ft41=2367, ft42=37, ft43=448, ft44=80, ft45=277, ft46=1407, ft48=1128, ft47=4366, ft49=0, ft51=1113, ft50=31777, ft52=4305, ft53=149, ft54=935, ft55=62, ft26=28.27, ft27=150.51, ft28=813, ft29=84, ft30=1910, ft31=14, ft32=883";
    case "6958230754638367" : return "ft1=2977, ft2=1319, ft3=1349, ft4=14, ft5=1927, ft6=746, ft7=134, ft8=1080, ft9=773, ft10=205, ft11=514, ft12=3, ft13=2556, ft14=250, ft15=1, ft16=4296, ft17=973, ft18=0, ft24=13988, ft25=300.34, ft19=568, ft39=20, ft20=1349, ft21=0, ft33=14, ft21=11830, ft35=864, ft22=3103, ft23=12, ft34=1455, ft36=734, ft37=40, ft38=0, ft40=382, ft41=2367, ft42=37, ft43=448, ft44=80, ft45=277, ft46=1407, ft48=1128, ft47=4366, ft49=0, ft51=1113, ft50=31777, ft52=4305, ft53=149, ft54=935, ft55=62, ft26=28.27, ft27=150.51, ft28=813, ft29=84, ft30=1910, ft31=14, ft32=883";
  }
}

?>
