<?php

# Copyright (C) 2004-2010 by Grigori Fursin
#
# http://fursin.net/research
# 
# UNIDAPT Group
# http://unidapt.org

$dir=getenv("CCC_PLUGINS");
if ($dir != "")
  $dir = $dir . "/";
$dir.="/include/";
include($dir . "ccc_script_functions.php");

$prog_id1=getenv("PROG_ID1");
$prog_id2=getenv("PROG_ID2");
$plat_id=getenv("PLAT_ID");
$env_id=getenv("ENV_ID");
$cmplr_id=getenv("CMPLR_ID");
$ds_num1=getenv("DS_NUM1");
$ds_num2=getenv("DS_NUM2");
$ds_id1=getenv("DS_ID1");
$ds_id2=getenv("DS_ID2");

$notes=getenv("NOTES");
$pg_use=(int)getenv("PG_USE");
$output_cor=1;
$output_cor1=getenv("OUTPUT_CORRECT");
 if ($output_cor1=="0") $output_cor=0;

$run_time=getenv("RUN_TIME");
 if ($run_time=="") $run_time="RUN_TIME";
$time_thr=(double)getenv("TIME_THRESHOLD");
 if ($time_thr==0) $time_thr="0.3";
$file_tmp=getenv("CCC_FILE_TMP");
 if ($file_tmp=="") $file_tmp="tmp";

$sort=getenv("SORT");

// Output file with stats
$fname=getenv("CCC_STATS");
$fo=fopen($fname . ".txt", 'w') or die("Error: Can't open output file with stats for writing\n");

// Print various parameters
ccc_print($fo, "PROG_ID1=              " . $prog_id1 . "\n");
ccc_print($fo, "DS_NUM1=               " . $ds_num1 . "\n");
ccc_print($fo, "DS_ID1=                " . $ds_id1 . "\n");
ccc_print($fo, "PROG_ID2=              " . $prog_id2 . "\n");
ccc_print($fo, "DS_NUM2=               " . $ds_num2 . "\n");
ccc_print($fo, "DS_ID2=                " . $ds_id2 . "\n");
ccc_print($fo, "PLAT_ID=               " . $plat_id . "\n");
ccc_print($fo, "ENV_ID=                " . $env_id . "\n");
ccc_print($fo, "CMPLR_ID=              " . $cmplr_id . "\n");
ccc_print($fo, "\n");
ccc_print($fo, "NOTES=                 " . $notes . "\n");
ccc_print($fo, "PG_USE=                " . $pg_use . "\n");
ccc_print($fo, "OUTPUT_CORRECT=        " . $output_cor . "\n");
ccc_print($fo, "RUN_TIME=              " . $run_time . "\n");
ccc_print($fo, "TIME_THRESHOLD=        " . $time_thr . "\n");
ccc_print($fo, "\n");
ccc_print($fo, "SORT=                  " . $sort . "\n");
ccc_print($fo, "\n");
ccc_print($fo, "CCC_FILE_TMP=          " . $file_tmp . "\n");

// Database parameters
$c_hostname=getenv("CCC_C_URL");
$c_database=getenv("CCC_C_DB");
$c_user    =getenv("CCC_C_USER");
$c_password=getenv("CCC_C_PASS");
$c_ssl     =getenv("CCC_C_SSL");
$ic_ssl=0;
 if ($c_ssl != "") $ic_ssl=MYSQL_CLIENT_SSL;

$ct_hostname=getenv("CCC_CT_URL");
$ct_database=getenv("CCC_CT_DB");
$ct_user    =getenv("CCC_CT_USER");
$ct_password=getenv("CCC_CT_PASS");
$ct_ssl     =getenv("CCC_CT_SSL");
$ict_ssl=0;
 if ($ct_ssl != "") $ict_ssl=MYSQL_CLIENT_SSL;

$hostname=getenv("CCC_URL");
$database=getenv("CCC_DB");
$user    =getenv("CCC_USER");
$password=getenv("CCC_PASS");
$ssl     =getenv("CCC_SSL");
$i_ssl=0;
 if ($ssl != "") $i_ssl=MYSQL_CLIENT_SSL;

$db_ver=getenv("CCC_DB_VER");

// Connect to the common database
echo "\n";
echo "Connecting to the common database ...\n";
$c_link=mysql_connect($c_hostname, $c_user, $c_password, true, $ic_ssl) or die( "Error: Unable to connect to the database\n");
ccc_mysql_select_db($c_database, $c_link, $db_ver);

// Connect to the database with experiments
echo "Connecting to the database with experiments $database ...\n";
$link=mysql_connect($hostname, $user, $password, true, $i_ssl) or die( "Error: Unable to connect to the database\n");
ccc_mysql_select_db($database, $link, $db_ver);

//Checking dataset id
ccc_print($fo, "\n");
if ($ds_num1!="0")
{
 ccc_print($fo, "Searching DS_ID associated with DS_NUM (" . $ds_num1 .")...\n");
 $ds_id1=get_dataset_id($prog_id1, $ds_num1, $c_link);
}

ccc_print($fo, "\n");
if ($ds_num2!="0")
{
 ccc_print($fo, "Searching DS_ID associated with DS_NUM (" . $ds_num2 .")...\n");
 $ds_id2=get_dataset_id($prog_id2, $ds_num2, $c_link);
}

ccc_print($fo, "DS_ID1=                 " . $ds_id1 . "\n");
ccc_print($fo, "DS_ID2=                 " . $ds_id2 . "\n");

//Get speedups
$opt_cases=get_opt_cases1($prog_id1, $plat_id, $env_id, $cmplr_id, $ds_id1, $time_thr, $output_cor, $run_time, $link, $c_link, $file_tmp, $pg_use, $notes);
$speedup=$opt_cases[0];
$info=$opt_cases[1];

$ns=sizeof($speedup[0]);

ccc_print($fo, "\n");
ccc_print($fo, "Number of cases: " . $ns . "\n");

$qavf="";

if ($ns>0)
{
  $opt_cases1=sort_speedups($speedup, $info, $sort);
  $xspeedup=$opt_cases1[0];
  $xinfo=$opt_cases1[1];

  $num_max=sizeof($xspeedup[0]);
  $speedup_max0=$xspeedup[0][0];
  $speedup_max1=$xspeedup[1][0];
  $speedup_max2=$xspeedup[2][0];
  $comp_id=$xinfo[1][0];

  $opt_arch=get_opt_flags_platform(get_opt_platform_id(
                              get_opt_platform_feature_id($comp_id, $link), $c_link), $cmplr_id, $c_link);
  $opt_id=get_opt_id($comp_id, $link);
  $opt=get_opt_flags(get_opt_id($comp_id, $link), $cmplr_id, $c_link);

  ccc_print($fo, "\n");
  ccc_print($fo, "*** PROGRAM1:\n");
  ccc_print($fo, "Max speedup =        " . $speedup_max0 . "\n");
  ccc_print($fo, "COMPILATION_ID =     " . $comp_id . "\n");
  ccc_print($fo, "OPT_ID =             " . $opt_id . "\n");
  ccc_print($fo, "OPT FLAGS PLATFORM = " . $opt_arch . "\n");
  ccc_print($fo, "OPT FLAGS =          " . $opt . "\n");

  //Get second highest speedup
  $opt_cases1=get_opt_cases1($prog_id2, $plat_id, $env_id, $cmplr_id, $ds_id2, $time_thr, $output_cor, $run_time, $link, $c_link, $file_tmp, $pg_use, $notes);
  $speedup=$opt_cases1[0];
  $info=$opt_cases1[1];

  $ns1=sizeof($speedup[0]);

  ccc_print($fo, "\n");
  ccc_print($fo, "Number of cases: " . $ns1 . "\n");

  if ($ns1>0)
  {
    $opt_cases1=sort_speedups($speedup, $info, $sort);
    $qspeedup=$opt_cases1[0];
    $qinfo=$opt_cases1[1];

    $qnum_max=sizeof($qspeedup[0]);
    $qspeedup_max0=$qspeedup[0][0];
    $qspeedup_max1=$qspeedup[1][0];
    $qspeedup_max2=$qspeedup[2][0];
    $qcomp_id=$xinfo[1][0];

    $qopt_arch=get_opt_flags_platform(get_opt_platform_id(
                                get_opt_platform_feature_id($qcomp_id, $link), $c_link), $cmplr_id, $c_link);
    $qopt_id=get_opt_id($qcomp_id, $link);
    $qopt=get_opt_flags(get_opt_id($qcomp_id, $link), $cmplr_id, $c_link);

    ccc_print($fo, "\n");
    ccc_print($fo, "*** PROGRAM2:\n");
    ccc_print($fo, "Max speedup =        " . $qspeedup_max0 . "\n");
    ccc_print($fo, "COMPILATION_ID =     " . $qcomp_id . "\n");
    ccc_print($fo, "OPT_ID =             " . $qopt_id . "\n");
    ccc_print($fo, "OPT FLAGS PLATFORM = " . $qopt_arch . "\n");
    ccc_print($fo, "OPT FLAGS =          " . $qopt . "\n");

    //Comparison of optimization on another program
    $uopt_cases=get_opt_cases_by_opt_id($prog_id2, $plat_id, $env_id, $cmplr_id, $ds_id2, $opt_id, $time_thr, $output_cor, $run_time, $link, $c_link, $pg_use);

    $uspeedup=$uopt_cases[0];
    $uinfo=$uopt_cases[1];

    if (sizeof($uspeedup)!=0)
    {
      $uspeedup_max0=$uspeedup[0];
      $uspeedup_max1=$uspeedup[1];
      $uspeedup_max2=$uspeedup[2];
      $ucomp_id=$uinfo[1];

      ccc_print($fo, "\n");
      ccc_print($fo, "*** OPT FROM PROGRAM1 TO PROGRAM2:\n");
      ccc_print($fo, "Speedup: " . $uspeedup_max0 . " vs " . $qspeedup_max0 . "\n");

      $qav=abs(($uspeedup_max0-$qspeedup_max0)*100/$qspeedup_max0);
      $qavf=sprintf("%4.1f", $qav);
    }
    else
      $qavf=-1;
  }
}

ccc_print($fo, "Difference (%) = " . $qavf . "\n");
fclose($fo);

$fo=fopen($fname . ".short.txt", 'w') or die("Error: Can't open output file with stats for writing\n");
 fwrite($fo, $qavf . "\n");
fclose($fo);

mysql_close();

?>
