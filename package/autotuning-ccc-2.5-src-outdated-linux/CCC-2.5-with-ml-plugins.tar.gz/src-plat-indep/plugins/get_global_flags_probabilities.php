<?php

# Copyright (C) 2004-2010 by Grigori Fursin
#
# http://fursin.net/research
# 
# UNIDAPT Group
# http://unidapt.org

$dir=getenv("CCC_PLUGINS");
if ($dir != "")
  $dir = $dir . "/";
$dir.="/include/";
include($dir . "ccc_script_functions.php");

$prog_id=getenv("PROG_ID");
$plat_id=getenv("PLAT_ID");
$env_id=getenv("ENV_ID");
$cmplr_id=getenv("CMPLR_ID");
$ds_num=getenv("DS_NUM");
$ds_id=getenv("DS_ID");

$notes=getenv("NOTES");
$pg_use=(int)getenv("PG_USE");
$output_cor=1;
$output_cor1=getenv("OUTPUT_CORRECT");
 if ($output_cor1=="0") $output_cor=0;

$run_time=getenv("RUN_TIME");
 if ($run_time=="") $run_time="RUN_TIME";
$time_thr=(double)getenv("TIME_THRESHOLD");
 if ($time_thr==0) $time_thr="0.3";
$iters_to_average=(int)getenv("NUM_ITERS_TO_AVERAGE");
 if ($iters_to_average==0) $iters_to_average=30;
$percent=(double)getenv("PERCENT_OF_SPEEDUP");
 if ($percent==0) $percent=95;

$spd_thr1=(double)getenv("SPEEDUP_THRESHOLD");
 if ($spd_thr1==0) $spd_thr1=1.03;
$spd_thr2=(double)getenv("SPEEDUP_THRESHOLD_L");
 if ($spd_thr2==0) $spd_thr2=0.96;
$spd_var=(double)getenv("SPEEDUP_VARIATION");
 if ($spd_var==0) $spd_var=0.003;

// Output file with stats
$fname=getenv("CCC_STATS");
$fo=fopen($fname . ".txt", 'w') or die("Error: Can't open output file with stats for writing\n");

// Database parameters
$c_hostname=getenv("CCC_C_URL");
$c_database=getenv("CCC_C_DB");
$c_user    =getenv("CCC_C_USER");
$c_password=getenv("CCC_C_PASS");
$c_ssl     =getenv("CCC_C_SSL");
$ic_ssl=0;
 if ($c_ssl != "") $ic_ssl=MYSQL_CLIENT_SSL;

$ct_hostname=getenv("CCC_CT_URL");
$ct_database=getenv("CCC_CT_DB");
$ct_user    =getenv("CCC_CT_USER");
$ct_password=getenv("CCC_CT_PASS");
$ct_ssl     =getenv("CCC_CT_SSL");
$ict_ssl=0;
 if ($ct_ssl != "") $ict_ssl=MYSQL_CLIENT_SSL;

$hostname=getenv("CCC_URL");
$database=getenv("CCC_DB");
$user    =getenv("CCC_USER");
$password=getenv("CCC_PASS");
$ssl     =getenv("CCC_SSL");
$i_ssl=0;
 if ($ssl != "") $i_ssl=MYSQL_CLIENT_SSL;

$db_ver=getenv("CCC_DB_VER");

// Output file with stats
$fname=getenv("CCC_STATS");
$fo=fopen($fname . ".txt", 'a') or die("Error: Can't open output file with stats for writing!\n");

// Print various parameters
ccc_print($fo, "PROG_ID=               " . $prog_id . "\n");
ccc_print($fo, "DS_NUM=                " . $ds_num . "\n");
ccc_print($fo, "PLAT_ID=               " . $plat_id . "\n");
ccc_print($fo, "ENV_ID=                " . $env_id . "\n");
ccc_print($fo, "CMPLR_ID=              " . $cmplr_id . "\n");
ccc_print($fo, "\n");
ccc_print($fo, "NOTES=                 " . $notes . "\n");
ccc_print($fo, "PG_USE=                " . $pg_use . "\n");
ccc_print($fo, "OUTPUT_CORRECT=        " . $output_cor . "\n");
ccc_print($fo, "RUN_TIME=              " . $run_time . "\n");
ccc_print($fo, "TIME_THRESHOLD=        " . $time_thr . "\n");
ccc_print($fo, "\n");
ccc_print($fo, "SPEEDUP_THRESHOLD=     " . $spd_thr1 . "\n");
ccc_print($fo, "SPEEDUP_THRESHOLD_L=   " . $spd_thr2 . "\n");
ccc_print($fo, "SPEEDUP_VARIATION=     " . $spd_var . "\n");

ccc_print($fo, "\n");
ccc_print($fo, "CCC_FILE_TMP=          " . $file_tmp . "\n");

// Connect to the common database
echo "\n";
echo "Connecting to the common database ...\n";
$c_link=mysql_connect($c_hostname, $c_user, $c_password, true, $ic_ssl) or die( "Error: Unable to connect to the database\n");
ccc_mysql_select_db($c_database, $c_link, $db_ver);

// Connect to the database with experiments
echo "Connecting to the database with experiments $database ...\n";
$link=mysql_connect($hostname, $user, $password, true, $i_ssl) or die( "Error: Unable to connect to the database\n");
ccc_mysql_select_db($database, $link, $db_ver);

//Checking dataset id
ccc_print($fo, "\n");
if ($ds_num!="0")
{
 ccc_print($fo, "Searching DS_ID associated with DS_NUM (" . $ds_num .")...\n");
 $ds_id=get_dataset_id($prog_id, $ds_num, $c_link);
}

ccc_print($fo, "DS_ID=    " . $ds_id . "\n");









//$fo=fopen($fname . ".short.txt", 'w') or die("Error: Can't open output file with stats for writing\n");
//fwrite($fo, $qavf . "\n");
//fclose($fo);

mysql_close();

?>
ex