<?php

# Copyright (C) 2009 by Grigori Fursin
# Some parts are written by Menjato Rakoto during internship
#
# http://fursin.net/research
# 
# UNIDAPT Group
# http://unidapt.org

function parse_sfv($liste)
{
  $vector = array();

  $ft_elt = explode(", ", $liste);

  for($i=0;$i<substr_count($liste,'ft');$i++) 
  {
    $ft_val = explode("=", $ft_elt[$i]);

    foreach($ft_val as $cle=>$val) 
    {
      if ($cle==0) $tmp_cle =substr($val,strpos($val,"t")+1);
      else $tmp_val =$val;
    }
    $vector[$tmp_cle] = $tmp_val;
  }
  return $vector;
}//end function

//Feature vector should be already correct
function sfv_normalize($sfv,$base_ft)
{	
  $nvect=array();
  $base=$sfv[$base_ft];
  if ($base!=0)
    foreach($sfv as $cle=>$val) 
      $nvect[$cle]=$val/$base;
  return $nvect;
}

function compare_sfv_ed($fv,$vect)
{
  $result=99999; //if wrong, very large distance, but it shouldn't happen normally ...
  $sum = 0;
  if (count($fv)==count($vect))
  {
    for ($i=1;$i<=count($fv);$i++)
      $sum = $sum + pow(abs(($fv[$i] - $vect[$i])),2);
    $result = sqrt($sum);
  }
  return $result;
}

//this function returns num of compile_id of one give platform given,one given environment and one given compiler
function get_sfv_compile_id($plat_id,$env_id,$cmplr_id,$link)//,$link)//,$env_id,$cmplr_id,$link)
{
  $ret=array();
  $query="SELECT DISTINCT STATS_COMP_GLOBAL_FLAGS.COMPILE_ID, PROGRAM_FEATURES.STATIC_FEATURE_VECTOR ".
          "FROM STATS_COMP_GLOBAL_FLAGS, PROGRAM_FEATURES".
          " WHERE (STATS_COMP_GLOBAL_FLAGS.PLATFORM_ID=" . $plat_id . ")".
          "AND (STATS_COMP_GLOBAL_FLAGS.ENVIRONMENT_ID=" . $env_id . ")".
          "AND (STATS_COMP_GLOBAL_FLAGS.COMPILER_ID=" . $cmplr_id . ")".
          "AND (PROGRAM_FEATURES.FUNCTION_NAME='')".
          "AND (STATS_COMP_GLOBAL_FLAGS.COMPILE_ID=PROGRAM_FEATURES.COMPILE_ID)";

  $result=mysql_query($query, $link);
  while ($row=mysql_fetch_assoc($result))  //get one row at a time
  {
    $cid =$row["COMPILE_ID"];
    $sfv=$row["STATIC_FEATURE_VECTOR"];
    $ret[$cid]=$sfv;
  }
  mysql_free_result($result);
  return $ret;
}

function get_sfv_compile_id1($cmplr_id,$link)
{
  $ret=array();
  $query="SELECT DISTINCT STATS_COMP_GLOBAL_FLAGS.COMPILE_ID, PROGRAM_FEATURES.STATIC_FEATURE_VECTOR ".
          "FROM STATS_COMP_GLOBAL_FLAGS, PROGRAM_FEATURES ".
          "WHERE (STATS_COMP_GLOBAL_FLAGS.COMPILER_ID=" . $cmplr_id . ")".
          "AND (PROGRAM_FEATURES.FUNCTION_NAME='')".
          "AND (STATS_COMP_GLOBAL_FLAGS.COMPILE_ID=PROGRAM_FEATURES.COMPILE_ID)";

  $result=mysql_query($query, $link);
  while ($row=mysql_fetch_assoc($result))  //get one row at a time
  {
    $cid =$row["COMPILE_ID"];
    $sfv=$row["STATIC_FEATURE_VECTOR"];
    $ret[$cid]=$sfv;
  }
  mysql_free_result($result);
  return $ret;
}

function is_sfv_valid($sfv, $base_st)
{
  $ret=true;
  if ($base_st==0)
  {
    if ((sizeof($sfv)==0) || (array_key_exists("0", $sfv)))
      $ret=false;
  }
  else if ((sizeof($sfv)==0) || (array_key_exists("0", $sfv)) || ($sfv[$base_st]==0))
    $ret=false;
  return $ret;
}

function find_all_opt_case_based_on_sfv($platid,$envid,$cmplrid,$sfv_orig,$base_ft,$link)
{
  $ret = array();
  $num = array();
  //get compile_id and test if this compile_id exist in program_features tables
  $num = get_sfv_compile_id($platid,$envid,$cmplrid,$link);

  if (sizeof($num)!=0)
  { 
    //normalize original vector
    $nsfv_orig=sfv_normalize($sfv_orig,$base_ft); //normalize with BASELINE

    //normalize and parsing
    $psfv = array(); //parsed vectors
    $nsfv = array(); //normalized vectors
    $dsfv = array(); //distance
    $csfv = array(); //comp_id
    $icsfv = array(); //comp_id invalid
    $transfert = array();
    $kmax=0;
    $qmax=0;
    foreach ($num as $cid=>$sfv) 
    {
      $xsfv=parse_sfv($sfv);//decompose each sfv
      if (is_sfv_Valid($xsfv, $base_ft))
      {
        $csfv[$kmax]=$cid;
        $psfv[$kmax]=$xsfv;
        $nsfv[$kmax]=sfv_normalize($xsfv,$base_ft); //normalize with BASELINE
        $dsfv[$kmax]=compare_sfv_ed($nsfv_orig,$nsfv[$kmax]); //compare it with the reference ft_flat and return euclidian

        $kmax++;
      }
      else
        $icsfv[$qmax++]=$cid;
    }

    //sorting all arrays (using first one)
    array_multisort($dsfv, $nsfv, $psfv, $csfv);

    $ret[0]=$csfv;
    $ret[1]=$psfv;
    $ret[2]=$nsfv;
    $ret[3]=$dsfv;
    $ret[4]=$icsfv;

  }//fin if

  return $ret;
}//fin function

function find_all_opt_case_based_on_sfv1($cmplrid,$sfv_orig,$base_ft,$link)
{
  $ret = array();
  $num = array();
  //get compile_id and test if this compile_id exist in program_features tables
  $num = get_sfv_compile_id1($cmplrid,$link);

  if (sizeof($num)!=0)
  { 
    //normalize original vector
    $nsfv_orig=sfv_normalize($sfv_orig,$base_ft); //normalize with BASELINE

    //normalize and parsing
    $psfv = array(); //parsed vectors
    $nsfv = array(); //normalized vectors
    $dsfv = array(); //distance
    $csfv = array(); //comp_id
    $icsfv = array(); //comp_id invalid
    $transfert = array();
    $kmax=0;
    $qmax=0;
    foreach ($num as $cid=>$sfv) 
    {
      $xsfv=parse_sfv($sfv);//decompose each sfv
      if (is_sfv_Valid($xsfv, $base_ft))
      {
        $csfv[$kmax]=$cid;
        $psfv[$kmax]=$xsfv;
        $nsfv[$kmax]=sfv_normalize($xsfv,$base_ft); //normalize with BASELINE
        $dsfv[$kmax]=compare_sfv_ed($nsfv_orig,$nsfv[$kmax]); //compare it with the reference ft_flat and return euclidian

        $kmax++;
      }
      else
        $icsfv[$qmax++]=$cid;
    }

    //sorting all arrays (using first one)
    array_multisort($dsfv, $nsfv, $psfv, $csfv);

    $ret[0]=$csfv;
    $ret[1]=$psfv;
    $ret[2]=$nsfv;
    $ret[3]=$dsfv;
    $ret[4]=$icsfv;

  }//fin if

  return $ret;
}//fin function

?>
