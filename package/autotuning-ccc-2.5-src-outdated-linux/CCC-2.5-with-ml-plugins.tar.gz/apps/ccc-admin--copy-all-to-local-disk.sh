#!/bin/bash

# Copyright (C) 2004-2009 by Grigori Fursin
#
# http://fursin.net/research
# 
# UNIDAPT Group
# http://unidapt.org

date

rm -rf /local/fursin/fggwork/apps-ccc
mkdir -p /local/fursin/fggwork/apps-ccc
cp -rf * /local/fursin/fggwork/apps-ccc
date

cd /local/fursin/fggwork/apps-ccc
