#/bin/sh
pushd /local/fursin/fggwork/spec2006
source shrc
popd
