#!/bin/bash

# Copyright (C) 2004-2009 by Grigori Fursin
#
# http://fursin.net/research
# 
# UNIDAPT Group
# http://unidapt.org

################################################################################
echo "*************** CCC: Select UUID variable ***************"

export PATH=$PWD/src-plat-indep/plugins:$PATH

### Check/select platform
if [ -z "$CCC_PLATFORM" ] ; then
 echo ""
 echo "CCC Platform has not been yet configured since \$CCC_PLATFORM variable is empty."
 echo ""
 echo "Run INSTALL.sh first!"
 rm -f *.tmp
 exit
fi

echo "Provide name of UUID tool (<Enter> for uuidgen):"
read CCC_UUID
if [ -z $CCC_UUID ] ; then
 CCC_UUID="uuidgen"
fi
export CCC_UUID

rm -f *.tmp
