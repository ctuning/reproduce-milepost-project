/*
 * Copyright (C) 2004-2009 by Grigori Fursin
 *
 * http://fursin.net/research
 *
 * UNIDAPT Group
 * http://unidapt.org
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <time.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>

#include "ccc/ccc.h"
#include "ccc/stat.h"
#include "ccc/stat-comp.h"
#include "ccc/futils.h"
#include "ccc/fuuid.h"

static char str1[8192];
static char stropt[8192];
static char strfeat[8192];

void init_sockaddr (struct sockaddr_in *name, const char *hostname, unsigned short int port);
void write_to_server (int filedes, char* feat, char* type);
void read_from_server(int filesrc, char* fname);

int main(int argc, char* argv[])
{
  int sock;
  struct sockaddr_in servername;
  int port=0;
  FILE* ff;

  /********************************************************************/
  printf("CCC PREDICT BEST FLAG (based on static program features)\n");

  if (argc<6)
  {
    printf("\n");
    
    printf("Usage:\n");
    printf(" ccc-ml-predict-best-flag <ML HOSTNAME> <ML PORT> <FILE WITH STATIC FEATURES> <FILE TO SAVE PREDICTED OPTS> <size/speed>\n");

    return 1;
  }

  /* Create the socket */
  sock = socket (PF_INET, SOCK_STREAM, 0);
  if (sock < 0)
  {
    printf("CCC Error: Can't create socket\n");
    exit(1);
  }
	
  /* Connect to the server */
  port=atoi(argv[2]);
  init_sockaddr (&servername, argv[1], port);
  if (0 > connect (sock, (struct sockaddr *) &servername, sizeof (servername)))
  {
    printf("CCC Error: Can't connect to server\n");
    exit(1);
  }
				       
  /* Read features */
  if ((ff=fopen(argv[3], "r"))==NULL)
  {
    printf("Error: Can't open file %s with features ...\n", argv[3]);
    exit(1);
  }

  if (fgets(strfeat, 8191, ff)==NULL)
  {
    printf("Error: Can't read file %s with features ...\n", argv[3]);
    exit(1);
  }
  fparse1(strfeat);
					      
  /* Send data to the server */
  write_to_server (sock, strfeat, argv[5]);
      
  /* Receive data from server */
  read_from_server (sock, argv[4]);   
	
  close (sock);

  exit(0);
}

void init_sockaddr (struct sockaddr_in *name, const char *hostname, unsigned short int port)
{
  struct hostent *hostinfo;
	     
  name->sin_family = AF_INET;
  name->sin_port = htons (port);
  hostinfo = gethostbyname (hostname);
  if (hostinfo == NULL) 
  {
    printf ("CCc Error: Unknown host %s ...\n", hostname);
    exit(1);
  }
  name->sin_addr = *(struct in_addr *) hostinfo->h_addr;
 /* memset(name->sin_zero,'\0',sizeof name->sin_zero); */
}

void write_to_server (int filedes, char* features, char* type)
{
  /* 57 feartures which are the aggregation of the features across all the functions per program */
  /* strcpy(features,"speed_bs 138 40 37 0 65 30 3 24 29 16 7 0 98 0 0 154 29 0 0 0 0 0 37 74 0 531 11 153 0 102 0 49 0 0 0 0 0 0 5 14 0 0 0 0 0 0 0 0 0 0 0 0 0 0 98 0 0\n"); */
  int nbytes;
  strcpy(str1, type);
  strcat(str1, " ");
  strcat(str1, features);
  strcat(str1, "\n");
  nbytes = send(filedes, str1, strlen (str1) + 1, 0); 

  if (nbytes < 0)
  {
    printf("CCC Error: Can't send data to server ...\n");
    exit(1);
  }
  else
  {
    printf("Sent features to the server:\n%s\n\n", features);    
  }
}

void read_from_server(int filesrc, char* fname)
{
  int nbytes;
  FILE* ff=NULL;

  memset(stropt, 0x0, 8192); /* cleaning buffer */
  nbytes = recv(filesrc, stropt,sizeof(stropt)-1, 0);
  if (nbytes < 0)
  {
    printf("CCC Error: Can't receive data from server ...\n");
    exit(1);
  }
  else
  {
    printf("Received opts from the server:\n%s\n\n", stropt);
  }

  fparse1(stropt);

  if ((ff=fopen(fname, "w"))==NULL)
  {
    printf("Error: Can't open file %s to write opts ...\n", fname);
    exit(1);
  }

  fprintf(ff, "%s\n", stropt);

  fclose(ff);
}
