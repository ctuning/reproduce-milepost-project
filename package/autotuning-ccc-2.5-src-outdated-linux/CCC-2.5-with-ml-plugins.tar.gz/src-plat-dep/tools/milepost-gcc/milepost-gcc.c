/*
 * Copyright (C) 2004-2010 by Grigori Fursin
 *
 * http://fursin.net/research
 *
 * UNIDAPT Group
 * http://unidapt.org
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <time.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>

#include "ccc/ccc.h"
#include "ccc/stat.h"
#include "ccc/stat-comp.h"
#include "ccc/futils.h"
#include "ccc/fuuid.h"

static char str_main[8192];
static char ccc_opts[8192];
static char str_main1[8192];
static char comp_name[128];
static char str1[8192];
static char str2[8192];
static char str3[8192];
static char str4[8192];
static char str5[8192];
static char str6[8192];
static char stropt[8192];
static char stroptmain[8192];
static char stroptadd[8192];
static char fobjmd5[128];
static char comp_id[128];
static char ip[128];
static char ici_passes[8192];
static char ici_features[8192];
static char func_name[1024];
static char var_ccc_comp_opts[8192];
static char var_ccc_plat_opts[8192];
static char opt_id[1024];

static char x_ctuning_opt[]="--ct-opt=";

int main(int argc, char* argv[])
{
  char* var_ccc_ici_use=NULL;
  char* var_ccc_ici_plugins=NULL;
  char* var_ccc_ici_passes_fn=NULL;
  char* var_ccc_ici_passes_ext=NULL;
  char* var_ccc_ici_passes_record_plugin=NULL;
  char* var_ccc_ici_passes_use_plugin=NULL;
  char* var_ccc_ici_ft_st_fn=NULL;
  char* var_ccc_ici_ft_st_ext=NULL;
  char* var_ccc_ici_ft_st_extract_plugin=NULL;
  char* var_ccc_opts=NULL;
  char* var_ici_prog_feat_pass=NULL;
  char* var_ici_verbose=NULL;
  char* var_ccc_cts_db=NULL;
  char* var_ccc_opt_arch_use=NULL;
  int ivar_ccc_opt_arch_use=0;
  char* var;

  char str_time_thr[1024]="";
  char str_notes[1024]="";
  char str_pg_use[1024]="";
  char str_output_cor[1024]="";
  char str_run_time[1024]="";
  char str_sort[1024]="";
  char str_dim[1024]="";
  char str_cut[1024]="";
  char str_opt_report[1024]="";

  char* var_plat_id=NULL;
  char* var_env_id=NULL;
  char* var_cmplr_id=NULL;
  char* var_cmplr_f_id=NULL;

  FILE* ff=NULL;
  FILE* ff1=NULL;
  int first=0;

  int x=0;
  int mode=0;

  strcpy(comp_name, "");
  strcpy(str_main, "");

  for (x=0; x<strlen(argv[0]); x++)
    if (argv[0][x]=='-')
    {
      strcpy(comp_name, &argv[0][x+1]);
      break;
    }

  for (x=1; x<argc; x++)
  {
    if      (strcmp(argv[x], "-Oml")==0) mode=1;
    else if (strcmp(argv[x], "--version")==0) mode=-1;
    else if (strcmp(argv[x], "--help")==0) mode=-1;
    else if (strcmp(argv[x], "--ct-test")==0) mode=-2;
    else if (strncmp(argv[x], x_ctuning_opt, strlen(x_ctuning_opt))==0)
    {
      strcpy(opt_id, argv[x]+strlen(x_ctuning_opt));
      mode=10;
    }
    else
    {
      strcat(str_main, argv[x]);
      strcat(str_main, " ");
    }
  }

  //Invoke original compiler and quit
  if (mode==0)
  {
    sprintf(str1, "%s %s %s", comp_name, ccc_opts, str_main);
    exit(system(str1));
  }

  printf("MILEPOST GCC V1.5 (wrapper for GCC to communicate with cTuning web services)\n\n");
  printf("Invoking collective tuning and machine learning mode ...\n\n");

  if (mode==-1)
  {
    printf("  Machine learning based self-tuning compiler\n");
    printf("  GPL License\n");
    printf("\n");
    printf("  Designed by Grigori Fursin during MILEPOST project (2006-2009)\n");
    printf("  Supported by cTuning community (2010-now)\n");
    printf("  (http://cTuning.org/milepost-gcc)\n");
    printf("\n");
    printf("  Options:\n");
    printf("    -Oml  - substitute -O levels and predict flags for a given program\n");
    printf("            to improve execution time, code size, compilation time\n");
    printf("            by correlating program features and optimizations\n");
    printf("            from the Collective Optimization Database at cTuning.org\n");
    printf("\n");
    printf("    --ct-test - Test cTuning web-service and database\n");
    printf("\n");
    printf("    --ct-opt=<OPT_ID> - Select optimization case from the Collective Optimization Database\n");
    printf("\n");

    sprintf(str1, "%s %s", comp_name, str_main);
    exit(system(str1));
  }

  fflush(stdout); fflush(stderr);

  //Checking variables
  if ((var_ccc_ici_use = getenv(CCC_ICI_USE)) == NULL)
  {
    printf("Error: Environment variable " CCC_ICI_USE " is not defined!\n");
    exit(1);
  }

  var_ici_verbose = getenv(ICI_VERBOSE);

  if ((var_ccc_ici_plugins = getenv(CCC_ICI_PLUGINS)) == NULL)
  {
    printf("Error: Environment variable " CCC_ICI_PLUGINS " is not defined!\n");
    exit(1);
  }

  if ((var_ccc_ici_passes_fn = getenv(CCC_ICI_PASSES_FN)) == NULL)
  {
    printf("Error: Environment variable " CCC_ICI_PASSES_FN " is not defined!\n");
    exit(1);
  }

  if ((var_ccc_ici_passes_ext = getenv(CCC_ICI_PASSES_EXT)) == NULL)
  {
    printf("Error: Environment variable " CCC_ICI_PASSES_EXT " is not defined!\n");
    exit(1);
  }

  if ((var_ccc_ici_passes_record_plugin = getenv(CCC_ICI_PASSES_RECORD_PLUGIN)) == NULL)
  {
    printf("Error: Environment variable " CCC_ICI_PASSES_RECORD_PLUGIN " is not defined!\n");
    exit(1);
  }

  if ((var_ccc_ici_ft_st_fn = getenv(CCC_ICI_FEATURES_ST_FN)) == NULL)
  {
    printf("Error: Environment variable " CCC_ICI_FEATURES_ST_FN " is not defined!\n");
    exit(1);
  }

  if ((var_ccc_ici_ft_st_ext = getenv(CCC_ICI_FEATURES_ST_EXT)) == NULL)
  {
    printf("Error: Environment variable " CCC_ICI_FEATURES_ST_EXT " is not defined!\n");
    exit(1);
  }

  if ((var_ccc_ici_ft_st_extract_plugin = getenv(CCC_ICI_FEATURES_ST_EXTRACT_PLUGIN)) == NULL)
  {
    printf("Error: Environment variable " CCC_ICI_FEATURES_ST_EXTRACT_PLUGIN " is not defined!\n");
    exit(1);
  }

  if ((var_ici_prog_feat_pass = getenv(ICI_PROG_FEAT_PASS)) == NULL)
  {
    printf("Error: Environment variable " ICI_PROG_FEAT_PASS " is not defined!\n");
    exit(1);
  }

  if ((var_plat_id = getenv(CCC_PLAT_ID)) == NULL)
  {
    printf("Error: Environment variable " CCC_PLAT_ID " is not defined!\n");
    exit(1);
  }

  if ((var_env_id = getenv(CCC_ENV_ID)) == NULL)
  {
    printf("Error: Environment variable " CCC_ENV_ID " is not defined!\n");
    exit(1);
  }

  if ((var_cmplr_id = getenv(CCC_COMPILER_ID)) == NULL)
  {
    printf("Error: Environment variable " CCC_COMPILER_ID " is not defined!\n");
    exit(1);
  }

  if ((var_cmplr_f_id = getenv(CCC_COMPILER_FEATURES_ID)) == NULL)
  {
    printf("Error: Environment variable " CCC_COMPILER_FEATURES_ID " is not defined!\n");
    exit(1);
  }

  if ((var_ccc_cts_db = getenv(CCC_CTS_DB)) == NULL)
  {
    printf("Error: Environment variable " CCC_CTS_DB " is not defined!\n");
    exit(1);
  }

  if ((var_ccc_opt_arch_use = getenv(CCC_OPT_ARCH_USE)) == NULL)
  {
    printf("Error: Environment variable " CCC_OPT_ARCH_USE " is not defined!\n");
    exit(1);
  }
  if (strcmp(var_ccc_opt_arch_use,"1")==0) ivar_ccc_opt_arch_use=1;

  if ((var=getenv(CCC_TIME_THRESHOLD)) != NULL)
    strcpy(str_time_thr, var);

  if ((var=getenv(CCC_NOTES)) != NULL)
    strcpy(str_notes, var);

  if ((var=getenv(CCC_PG_NOTE)) != NULL)
    strcpy(str_pg_use, var);

  if ((var=getenv(CCC_OUTPUT_CORRECT)) != NULL)
    strcpy(str_output_cor, var);

  if ((var=getenv(CCC_RUN_TIME)) != NULL)
    strcpy(str_run_time, var);

  if ((var=getenv(CCC_SORT)) != NULL)
    strcpy(str_sort, var);

  if ((var=getenv(CCC_DIR)) != NULL)
    strcpy(str_dim, var);

  if ((var=getenv(CCC_CUT)) != NULL)
    strcpy(str_cut, var);

  if ((var=getenv(CT_OPT_REPORT)) != NULL)
    strcpy(str_opt_report, var);

  strcpy(ccc_opts, "");
  if ((var_ccc_opts=getenv(CCC_OPTS)) !=NULL)
    strcpy(ccc_opts, var_ccc_opts);

  fflush(stdout); fflush(stderr);

  //Testing cTuning web services
  if (mode==-2)
  {
    printf("Testing cTuning.org web-service ...\n");

    //prepare file to send to web-service
    if (get_filename_uuid(str3, _tmp1 ".%s.tmp"))
    {
      printf("\nError: Can't generate TMP file using UUID!\n");
      exit(1);
    }

    //prepare file for response
    if (get_filename_uuid(str4, _tmp1 ".%s.tmp"))
    {
      printf("\nError: Can't generate TMP file using UUID!\n");
      exit(1);
    }

    ff1 = fopen (str3, "w");
    fprintf(ff1, "TEST=ctuning_test\n");
    fclose(ff1);

    setenv("CCC_FILE", str3, 1); 
    setenv("CCC_FILE_OUT", str4, 1); 
    setenv("CCC_WEB_SERVICE", "ctuning_web_service_test", 1); 
    setenv("CCC_CTS_DB", var_ccc_cts_db, 1);

    fflush(stdout); fflush(stderr);

    system("web-service-cod > /dev/null");

    ff1 = fopen (str4, "r");
    if (ff1!=NULL)
    {
      fgets(str2, 8190, ff1);
      fclose(ff1);
    }

    printf("\nResponse from web-service:\n");
    printf("%s\n", str2);
    exit(0);
  }

  //Obtaining cTuning optimization case by ID
  if (mode==10)
  {
    printf("Quering cTuning.org web-service to obtain optimizations for opt_id=%s ...\n", opt_id);

    //prepare file to send to web-service
    if (get_filename_uuid(str3, _tmp1 ".%s.tmp"))
    {
      printf("\nError: Can't generate TMP file using UUID!\n");
      exit(1);
    }

    //prepare file for response
    if (get_filename_uuid(str4, _tmp1 ".%s.tmp"))
    {
      printf("\nError: Can't generate TMP file using UUID!\n");
      exit(1);
    }

    ff1 = fopen (str3, "w");
    fprintf(ff1, "OPT_ID=%s\n", opt_id);
    fclose(ff1);

    setenv("CCC_FILE", str3, 1); 
    setenv("CCC_FILE_OUT", str4, 1); 
    setenv("CCC_WEB_SERVICE", "get_ctuning_opt_case", 1); 
    setenv("CCC_CTS_DB", var_ccc_cts_db, 1);

    fflush(stdout); fflush(stderr);

    system("web-service-cod > /dev/null");

    ff1 = fopen (str4, "r");
    if (ff1==NULL)
    {
      printf("Error: Can't find response file!\n");
      exit(1);
    }

    strcpy(str2,"");
    strcpy(str5,"");

    fgets(str2, 8190, ff1);
    fgets(str5, 8190, ff1);

    fclose(ff1);

    strcpy(str1, "");
    if (strncmp(str2, "OPT_FLAGS=",10)==0)
    {
      strcpy(str1, &str2[10]);
      fparse1(str1);
    }
    else
    {
      printf("\nResponse from cTuning web-service:\n%s", str2);
    }

    strcpy(str6, "");
    if (strncmp(str5, "OPT_FLAGS_ARCH=",15)==0)
    {
      strcpy(str6, &str5[15]);
      fparse1(str6);
    }

    printf("\n");
    if (strcmp(str1, "")==0)
    {
      printf("Couldn't find better optimizations based on program features - using default optimizations ...\n");
      sprintf(str2, "%s %s %s", comp_name, ccc_opts, str_main);
    }
    else
    {
      //Select optimization
      printf("Returned associated flags from cTuning:\n");
      printf(" %s\n", str1);
      if (ivar_ccc_opt_arch_use==0) strcpy(str6, "");
      sprintf(str2, "%s %s %s %s", comp_name, str1, str6, str_main);
    }

    printf("\nInvoking command:\n%s\n", str2);

    fflush(stdout); fflush(stderr);

    setenv(var_ccc_ici_use, "0", 1); 
    exit(system(str2));
  }

  //Continue machine learning mode

  //Extract features
  printf("Extracting program static features (-O1) ...\n");
  setenv(var_ccc_ici_use, "1", 1); 
  setenv(var_ccc_ici_plugins, var_ccc_ici_passes_record_plugin, 1);

  sprintf(str1, _del " %s.*%s", var_ccc_ici_ft_st_fn, var_ccc_ici_ft_st_ext);
  system(str1);

  sprintf(str1, _del " *.ft");
  system(str1);

  sprintf(str1, "%s -O1 %s", comp_name, str_main);

  if (var_ici_verbose==NULL)
    strcat(str1, " > /dev/null 2> /dev/null");

  fflush(stdout); fflush(stderr);

  system(str1);

  //Compile again and extract features after specific pass
  setenv(var_ccc_ici_use, "1", 1); 
  setenv(var_ccc_ici_plugins, var_ccc_ici_ft_st_extract_plugin, 1);

  fflush(stdout); fflush(stderr);

  system(str1);

  //prepare list of files
  if (get_filename_uuid(str3, _tmp1 ".%s.tmp"))
  {
    printf("\nError: Can't generate TMP file using UUID!\n");
    exit(1);
  }

  fflush(stdout); fflush(stderr);

  sprintf(str2, _dir " %s.*%s > %s", var_ccc_ici_ft_st_fn, var_ccc_ici_ft_st_ext, str3);
  system(str2);

  sprintf(str2, ".%s%s",var_ici_prog_feat_pass, var_ccc_ici_ft_st_ext);

  //read file with features
  ff=fopen(str3, "r");
  if (ff!=NULL)
  {
    while (fgets(str1, 8191, ff)!=NULL)
    {
      int il=0;
      fparse1(str1);
      il=strlen(str1)-strlen(var_ccc_ici_ft_st_fn)-strlen(str2)-1;
      strncpy(func_name, &str1[strlen(var_ccc_ici_ft_st_fn)]+1, il);
      func_name[il]=0;

//      printf("Recording function features %s ...\n", func_name);

      first=1;
      ff1 = fopen (str1, "r");
      if (ff1!=NULL)
      {
        fgets(str1, 1023, ff1);
        fclose(ff1);
      }
      else
        printf("\nWarning: Can't find file %s with features!\n", str1);
      strcpy(ici_features, str1);
    }

    fclose(ff);
  }

  //accumulate features
  printf("\nAggregating features ...\n");

  fflush(stdout); fflush(stderr);

  sprintf(str2, _ccc_ml_accum_ft " %s %s", str3, var_ccc_ici_ft_st_fn);
  system(str2);

  sprintf(str2, "%s%s", var_ccc_ici_ft_st_fn, var_ccc_ici_ft_st_ext);

  first=1;
  ff1 = fopen (str2, "r");
  if (ff1!=NULL)
  {
    fgets(str1, 1023, ff1);
    fclose(ff1);
  }
  else
    printf("\nWarning: Can't find file %s with features!\n", str1);

  if (strcmp(str1, "")!=0 && strcmp(str1, "\n")!=0)
  {
    fparse1(str1);

    printf("\nStatic program features:\n%s\n", str1);
    strcpy(ici_features, str1);

    fflush(stdout); fflush(stderr);

    sprintf(str2, _del " %s", str3);
    system(str2);

    //Submit features to the server
    strcpy(str1,"");
    printf("\nSubmitting features to the cTuning web-service to predict good optimizations ...\n");

    //prepare file to send to web-service
    if (get_filename_uuid(str3, _tmp1 ".%s.tmp"))
    {
      printf("\nError: Can't generate TMP file using UUID!\n");
      exit(1);
    }

    //prepare file for response
    if (get_filename_uuid(str4, _tmp1 ".%s.tmp"))
    {
      printf("\nError: Can't generate TMP file using UUID!\n");
      exit(1);
    }

    ff1 = fopen (str3, "w");
    fprintf(ff1, "PLATFORM_ID=%s\n", var_plat_id);
    fprintf(ff1, "ENVIRONMENT_ID=%s\n", var_env_id);
    fprintf(ff1, "COMPILER_ID=%s\n", var_cmplr_id);
    fprintf(ff1, "COMPILER_FEATURES_ID=%s\n", var_cmplr_f_id);
    fprintf(ff1, "ST_PROG_FEAT=%s\n", ici_features);
    fprintf(ff1, CCC_TIME_THRESHOLD "=%s\n", str_time_thr);
    fprintf(ff1, CCC_NOTES "=%s\n", str_notes);
    fprintf(ff1, CCC_PG_NOTE "=%s\n", str_pg_use);
    fprintf(ff1, CCC_OUTPUT_CORRECT "=%s\n", str_output_cor);
    fprintf(ff1, CCC_RUN_TIME "=%s\n", str_run_time);
    fprintf(ff1, CCC_SORT "=%s\n", str_sort);
    fprintf(ff1, CCC_DIR "=%s\n", str_dim);
    fprintf(ff1, CCC_CUT "=%s\n", str_cut);
    fprintf(ff1, CT_OPT_REPORT "=%s\n", str_opt_report);

    fclose(ff1);

    setenv("CCC_FILE", str3, 1); 
    setenv("CCC_FILE_OUT", str4, 1); 
    setenv("CCC_WEB_SERVICE", "predict_opt", 1); 
    setenv("CCC_CTS_DB", var_ccc_cts_db, 1);

    fflush(stdout); fflush(stderr);

    system("web-service-cod > /dev/null");

    ff1 = fopen (str4, "r");
    if (ff1==NULL)
    {
      printf("Error: Can't find response file!\n");
      exit(1);
    }

    strcpy(str1, "");
    strcpy(str2,"");
    strcpy(str5,"");
    strcpy(str6,"");

    if (!feof(ff1)) fgets(str2, 8190, ff1);
     if (strncmp(str2, "OPT_FLAGS=",10)==0)
     {
       strcpy(str1, &str2[10]);
       fparse1(str1);
     }
     else
       printf("\nResponse from cTuning web-service:\n%s", str2);

    if (!feof(ff1)) fgets(str5, 8190, ff1);
     if (strncmp(str5, "OPT_FLAGS_ARCH=",15)==0)
     {
       strcpy(str6, &str5[15]);
       fparse1(str6);
     }

    if (!feof(ff1)) fgets(str2, 8190, ff1);
     if (strncmp(str2, "CTUNING_OPTIMIZATION_REPORT=",28)==0)
     {
       printf("\ncTuning Optimization Report (optimal optimization cases):\n\n");
       while (!feof(ff1))
       {
         strcpy(str2, "");
         fgets(str2, 8190, ff1);
         fparse1(str2);
         printf("%s\n", str2);
       }
     }

    fclose(ff1);

    sprintf(str2, _del " %s", str3);
    system(str2);

    sprintf(str2, _del " %s", str4);
    system(str2);

    printf("\n");
    if (strcmp(str1, "")==0)
    {
      printf("Couldn't find better optimizations based on program features - using default optimizations ...\n");
      sprintf(str2, "%s %s %s", comp_name, ccc_opts, str_main);
    }
    else
    {
      //Select optimization
      printf("Predicted flags:\n");
      printf(" %s\n", str1);
      if (ivar_ccc_opt_arch_use==0) strcpy(str6, "");
      sprintf(str2, "%s %s %s %s", comp_name, str1, str6, str_main);
    }
  }
  else
  {
    printf("\nCouldn't generate program features for this program - using default optimizations ...\n");
    sprintf(str2, "%s %s %s", comp_name, ccc_opts, str_main);
  }

  printf("\nInvoking command:\n%s\n", str2);

  fflush(stdout); fflush(stderr);

  setenv(var_ccc_ici_use, "0", 1); 
  exit(system(str2));
}
