You may be interested to look at the official release of MILEPOST GCC that include various demos too:
http://cTuning.org/milepost-gcc
