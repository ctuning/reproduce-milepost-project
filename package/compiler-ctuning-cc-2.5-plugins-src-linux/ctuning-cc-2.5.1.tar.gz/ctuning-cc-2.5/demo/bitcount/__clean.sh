#!/bin/bash

# Author: Grigori Fursin (http://fursin.net/research)
#
# (C) 2010, University of Versailles at Saint-Quentin-en-Yvelines, France

rm -f *.tmp
rm -f ici*
rm -f *.P
rm -f *.xwam
rm -f a.out
rm -f _ctuning_program_structure.txt
