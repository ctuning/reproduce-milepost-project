#!/bin/bash

# Author: Grigori Fursin (http://cTuning.org/lab/people/gfursin)
#
# (C) 2011-2012, INRIA, France
# (C) 2010, University of Versailles at Saint-Quentin-en-Yvelines, France
# (C) 2007-2010, UNIDAPT Group, INRIA, France (http://unidapt.org)

rm -f *.tmp
rm -f ici*
rm -f *.P
rm -f *.xwam
rm -f a.out
rm -f _ctuning_program_structure.txt
