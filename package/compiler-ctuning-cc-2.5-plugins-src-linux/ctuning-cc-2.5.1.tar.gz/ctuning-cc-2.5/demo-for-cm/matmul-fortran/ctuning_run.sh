#!/bin/bash

# Copyright (C) 2007-2010 by Grigori Fursin
#
# http://fursin.net/research
# 
# UNIDAPT Group
# http://unidapt.org

time ./a.out > ftmp_out
