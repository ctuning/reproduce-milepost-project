#!/bin/bash

# Author: Grigori Fursin (http://cTuning.org/lab/people/gfursin)
#
# (C) 2011-2012, INRIA, France
# (C) 2010, University of Versailles at Saint-Quentin-en-Yvelines, France
# (C) 2007-2010, UNIDAPT Group, INRIA, France (http://unidapt.org)

. ../set_environment_for_analysis_compiler__milepost_gcc.sh
. ../ctuning_common_environment.sh
. ../ctuning_clean.sh

#Trigger transparent program structure extraction and aggregate info about compiled program
export CTUNING_EXTRACT_STRUCTURE=$PWD/_ctuning_program_structure.txt

#remove optimization flags specified in the following file when processing CMD
#(to avoid interference between original and predicted optimizations)
export CTUNING_FILE_REMOVE_OPT_FLAGS=$PWD/_ctuning_remove_opt_flags.gcc44p

#files are removed since they will be appended
rm -f $CTUNING_EXTRACT_STRUCTURE

#substitute original optimizations
export CCC_OPTS=-"O2 -funroll-loops"

make clean
make CC=ctuning-cc
