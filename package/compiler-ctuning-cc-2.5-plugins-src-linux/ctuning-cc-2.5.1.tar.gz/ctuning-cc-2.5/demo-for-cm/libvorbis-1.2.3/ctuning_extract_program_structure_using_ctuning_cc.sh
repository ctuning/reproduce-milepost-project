#!/bin/bash

# Author: Grigori Fursin (http://cTuning.org/lab/people/gfursin)
#
# (C) 2011-2012, INRIA, France
# (C) 2010, University of Versailles at Saint-Quentin-en-Yvelines, France
# (C) 2007-2010, UNIDAPT Group, INRIA, France (http://unidapt.org)

. ../set_environment_for_analysis_compiler__milepost_gcc.sh
. ../ctuning_common_environment.sh
. ../ctuning_clean.sh

#Select only a few functions to process
export ICI_FILE_SELECT_FUNCTIONS=$PWD/_ctuning_select_functions.txt

#Change optimization level for the analysis compiler
#(normally should be used with the removal of optimization flags)
#export CTUNING_ANALYSIS_OPT_LEVEL=-O2

#remove optimization flags specified in the following file when processing CMD
#(to avoid interference between original and predicted optimizations)
export CTUNING_FILE_REMOVE_OPT_FLAGS=$PWD/_ctuning_remove_opt_flags.gcc44p

CTUNING_FLAGS="--ct-extract-structure -Wall -Winline -g"

make clean
make CC=ctuning-cc CFLAGS="$CTUNING_FLAGS"
