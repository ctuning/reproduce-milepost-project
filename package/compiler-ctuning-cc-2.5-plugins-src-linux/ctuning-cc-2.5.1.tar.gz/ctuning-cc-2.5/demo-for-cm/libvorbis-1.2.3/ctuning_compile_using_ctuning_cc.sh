#!/bin/bash

# Author: Grigori Fursin (http://cTuning.org/lab/people/gfursin)
#
# (C) 2011-2012, INRIA, France
# (C) 2010, University of Versailles at Saint-Quentin-en-Yvelines, France
# (C) 2007-2010, UNIDAPT Group, INRIA, France (http://unidapt.org)

. ../set_environment_for_analysis_compiler__milepost_gcc.sh
. ../ctuning_common_environment.sh
. ../ctuning_clean.sh

make clean
make CC=ctuning-cc
