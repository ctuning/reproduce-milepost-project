#!/bin/bash

# Author: Grigori Fursin (http://cTuning.org/lab/people/gfursin)
#
# (C) 2011-2012, INRIA, France
# (C) 2010, University of Versailles at Saint-Quentin-en-Yvelines, France
# (C) 2007-2010, UNIDAPT Group, INRIA, France (http://unidapt.org)

read -s -p "  Enter cTuning password for $CCC_CTS_USER : " pass
export CCC_CTS_PASS=$pass
echo ""

#Select only a few functions to process when predicting optimizations
#export ICI_FILE_SELECT_FUNCTIONS=$PWD/_ctuning_select_functions.txt

time ./__run1.sh

echo ""
echo "Output:"
more ftmp_out