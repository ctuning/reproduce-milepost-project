#!/bin/bash

# Author: Grigori Fursin (http://fursin.net/research)
#
# (C) 2010, University of Versailles at Saint-Quentin-en-Yvelines, France

export CM_CODE_DEP_CTUNING_CC="3285d9a46e5a04d7"
. cm_code_env_${CM_CODE_DEP_CTUNING_CC}.sh

export CM_CODE_DEP_CTUNING_CC_PLUGINS="5b03050b0a6767a7"
. cm_code_env_${CM_CODE_DEP_CTUNING_CC_PLUGINS}.sh
